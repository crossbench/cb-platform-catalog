(function () {
  var store = { get: function (k) { try { return store.get(k); } catch (e) { return null; } }, set: function (k, v) { try { store.set(k, v); } catch (e) {} } };
  var FACES = ['🐰', '🐱', '🐶', '🐥', '🐼'];
  var grid = document.getElementById('grid');
  var scoreEl = document.getElementById('score');
  var timeEl = document.getElementById('time');
  var bestEl = document.getElementById('best');
  var msgEl = document.getElementById('message');
  var startBtn = document.getElementById('startBtn');
  var holes = [];
  var score = 0, timeLeft = 30, playing = false;
  var spawnTimer = null, countTimer = null, current = -1;

  var best = parseInt(store.get('pokopoko_best') || '0', 10);
  bestEl.textContent = best;

  for (var i = 0; i < 9; i++) {
    var d = document.createElement('div');
    d.className = 'hole';
    var s = document.createElement('span');
    s.className = 'face';
    d.appendChild(s);
    (function (idx) {
      d.addEventListener('pointerdown', function () {
        if (playing && idx === current) {
          score += 1;
          scoreEl.textContent = score;
          hide();
          spawn();
        }
      });
    })(i);
    grid.appendChild(d);
    holes.push(d);
  }

  function hide() {
    if (current >= 0) holes[current].classList.remove('up');
    current = -1;
  }
  function spawn() {
    hide();
    var next;
    do { next = Math.floor(Math.random() * 9); } while (next === current);
    current = next;
    holes[current].querySelector('.face').textContent = FACES[Math.floor(Math.random() * FACES.length)];
    holes[current].classList.add('up');
  }
  function end() {
    playing = false;
    clearInterval(spawnTimer); clearInterval(countTimer);
    hide();
    if (score > best) {
      best = score;
      store.set('pokopoko_best', String(best));
      bestEl.textContent = best;
    }
    msgEl.innerHTML = 'おわり！ スコアは <b>' + score + '</b> でした。<br>ベストスコア: <b>' + best + '</b>';
    startBtn.textContent = 'もう一度';
    startBtn.style.display = '';
  }
  startBtn.addEventListener('click', function () {
    score = 0; timeLeft = 30; playing = true;
    scoreEl.textContent = '0'; timeEl.textContent = '30';
    msgEl.textContent = 'がんばって！';
    startBtn.style.display = 'none';
    spawn();
    spawnTimer = setInterval(spawn, 800);
    countTimer = setInterval(function () {
      timeLeft -= 1;
      timeEl.textContent = timeLeft;
      if (timeLeft <= 0) end();
    }, 1000);
  });
})();
