'use strict';
/* ワンナイト人狼：1台のスマホを回して遊ぶパスアンドプレイ版。
   役職は 人狼×2・占い師・怪盗・村人（残り）。中央に2枚のカードが残る。
   夜の行動は 人狼→占い師→怪盗→村人 の順に、各自が端末を受け取って行う。 */
const SAVE_KEY = 'escape-platform:onenight-jinro:save-v1';

const ROLES = {
  werewolf:     { name: '人狼',           icon: '🐺', team: 'wolf' },
  minion:       { name: '狂人',           icon: '🎭', team: 'wolf' },
  seer:         { name: '占い師',         icon: '🔮', team: 'village' },
  robber:       { name: '怪盗',           icon: '🌀', team: 'village' },
  troublemaker: { name: 'トラブルメーカー', icon: '🔀', team: 'village' },
  drunk:        { name: '酔っぱらい',     icon: '🍺', team: 'village' },
  insomniac:    { name: '不眠症',         icon: '🦉', team: 'village' },
  villager:     { name: '村人',           icon: '🧑‍🌾', team: 'village' }
};
const ROLE_ORDER = ['werewolf', 'minion', 'seer', 'robber', 'troublemaker', 'drunk', 'insomniac', 'villager'];
const SPECIAL_ROLES = ['seer', 'robber', 'minion', 'troublemaker', 'drunk', 'insomniac'];

const $screen = document.getElementById('screen');
function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ---------- 状態 ----------
let S = null;
function freshState() {
  return {
    screen: 'setup',
    settings: { count: 4, names: ['', '', '', '', '', ''], minutes: 3, roles: { seer: true, robber: true, minion: false, troublemaker: false, drunk: false, insomniac: false } },
    setupError: null,
    players: [],        // {name, initialRole, finalRole}
    center: [],         // [role, role]
    nightQueue: [],     // プレイヤー番号（夜の行動順）
    nightPos: 0,
    nightStep: 'reveal',// reveal | pick | outcome
    nightInfo: null,    // そのターンの表示情報
    votes: [],          // プレイヤー番号 -> 投票先のプレイヤー番号
    votePos: 0,
    log: [],            // 夜の出来事（結果画面で公開）
    discussEndsAt: 0,
    discussLeft: 0,
    timerOn: false
  };
}
function playerName(i) {
  const n = (S.settings.names[i] || '').trim();
  return n || ('プレイヤー' + (i + 1));
}
function save() {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(S)); } catch (e) { /* 保存不可でも続行 */ }
}
function load() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return false;
    const s = JSON.parse(raw);
    if (!s || !s.settings || !Array.isArray(s.players)) return false;
    S = Object.assign(freshState(), s);
    if (!S.settings.roles) S.settings.roles = freshState().settings.roles;
    // プライベート情報が見える画面で復元しないよう、受け渡し画面に戻す
    if (S.screen === 'nightRole') S.screen = 'nightHandoff';
    if (S.screen === 'votePick') S.screen = 'voteHandoff';
    return true;
  } catch (e) { return false; }
}

// ---------- ゲーム進行 ----------
function startGame() {
  const count = S.settings.count;
  const specials = SPECIAL_ROLES.filter(r => S.settings.roles[r]);
  if (specials.length > count) {
    S.setupError = '選んだ役職が多すぎます（' + count + '人では特殊役職は最大' + count + 'つまで）。役職を減らすか人数を増やしてください。';
    S.screen = 'setup';
    save(); render();
    return;
  }
  S.setupError = null;
  const deck = ['werewolf', 'werewolf'].concat(specials);
  while (deck.length < count + 2) deck.push('villager');
  shuffle(deck);
  S.players = [];
  for (let i = 0; i < count; i++) {
    S.players.push({ name: playerName(i), initialRole: deck[i], finalRole: deck[i] });
  }
  S.center = [deck[count], deck[count + 1]];
  // 夜の行動順：役職順（人狼→占い師→怪盗→村人）、同役職は席順
  S.nightQueue = S.players.map((p, i) => i).sort((a, b) => {
    const d = ROLE_ORDER.indexOf(S.players[a].initialRole) - ROLE_ORDER.indexOf(S.players[b].initialRole);
    return d !== 0 ? d : a - b;
  });
  S.nightPos = 0;
  S.votes = new Array(count).fill(-1);
  S.votePos = 0;
  S.log = [];
  S.timerOn = false;
  S.screen = 'nightIntro';
  save(); render();
}

function currentNightPlayer() { return S.nightQueue[S.nightPos]; }

function beginNightTurn() {
  S.nightStep = 'reveal';
  S.nightInfo = null;
  S.screen = 'nightRole';
  save(); render();
}

function endNightTurn() {
  S.nightPos++;
  if (S.nightPos >= S.nightQueue.length) {
    S.screen = 'discuss';
    S.discussLeft = S.settings.minutes * 60;
    S.discussEndsAt = 0;
    S.timerOn = false;
  } else {
    S.screen = 'nightHandoff';
  }
  save(); render();
}

// 夜の行動（initialRole で判定。占い師の時点では交換はまだ起きていない）
function nightActionHTML(me) {
  const role = S.players[me].initialRole;
  if (S.nightStep === 'outcome') {
    return '<div class="card light"><div class="roleicon">' + S.nightInfo.icon + '</div>' +
      '<p class="big">' + S.nightInfo.text + '</p></div>' +
      '<button id="doneBtn">閉じて次へ</button>';
  }
  if (role === 'werewolf') {
    const mates = S.players.filter((p, i) => i !== me && p.initialRole === 'werewolf');
    if (mates.length > 0) {
      S.nightStep = 'outcome';
      S.nightInfo = { icon: '🐺', text: '仲間の人狼は ' + mates.map(p => esc(p.name)).join('、') + ' さんです' };
      S.log.push('🐺 人狼どうしが互いを確認した');
      return nightActionHTML(me);
    }
    if (S.nightStep === 'reveal') {
      return '<p>あなたは一匹狼です。<br>中央のカードを1枚だけ見られます。</p>' +
        '<button class="pick" data-center="0">中央のカード（左）を見る</button>' +
        '<button class="pick" data-center="1">中央のカード（右）を見る</button>';
    }
  }
  if (role === 'seer') {
    if (S.nightStep === 'reveal') {
      return '<p>だれかのカード1枚か、中央のカード2枚を見られます。</p>' +
        '<button class="pick" id="seerPlayer">プレイヤーのカードを見る</button>' +
        '<button class="pick" id="seerCenter">中央のカード2枚を見る</button>';
    }
    if (S.nightStep === 'pick') {
      return '<p>だれのカードを見ますか？</p>' + S.players.map((p, i) =>
        i === me ? '' : '<button class="pick" data-target="' + i + '">' + esc(p.name) + ' さん</button>').join('');
    }
  }
  if (role === 'robber') {
    if (S.nightStep === 'reveal' || S.nightStep === 'pick') {
      return '<p>だれかと自分のカードを交換できます。<br>交換すると、相手の役職があなたのものになります。</p>' +
        S.players.map((p, i) =>
          i === me ? '' : '<button class="pick" data-target="' + i + '">' + esc(p.name) + ' さんと交換</button>').join('') +
        '<button class="pick" id="robberSkip">交換しない</button>';
    }
  }
  if (role === 'minion') {
    const wolves = S.players.filter(p => p.initialRole === 'werewolf');
    S.nightStep = 'outcome';
    S.nightInfo = wolves.length
      ? { icon: '🎭', text: '人狼は ' + wolves.map(p => esc(p.name)).join('、') + ' さんです。人狼を守ってください。' }
      : { icon: '🎭', text: 'プレイヤーの中に人狼はいません。' };
    S.log.push('🎭 狂人（' + S.players[me].name + '）は人狼を確認した');
    return nightActionHTML(me);
  }
  if (role === 'troublemaker') {
    if (!S.nightInfo) S.nightInfo = { picks: [] };
    const picks = S.nightInfo.picks;
    return '<p>他の2人のカードを、中身を見ずに入れ替えられます。</p>' +
      S.players.map((p, i) => i === me ? '' :
        '<button class="pick" data-tmpick="' + i + '">' + (picks.includes(i) ? '✅ ' : '') + esc(p.name) + ' さん</button>').join('') +
      '<button id="tmConfirm"' + (picks.length === 2 ? '' : ' disabled') + '>この2人を入れ替える</button>' +
      '<button class="sub" id="tmSkip">入れ替えない</button>';
  }
  if (role === 'drunk') {
    return '<p>自分のカードを、中央のカード1枚と交換しなければなりません。<br>新しい役職は朝まで分かりません。</p>' +
      '<button class="pick" data-drunk="0">中央のカード（左）と交換</button>' +
      '<button class="pick" data-drunk="1">中央のカード（右）と交換</button>';
  }
  if (role === 'insomniac') {
    S.nightStep = 'outcome';
    const cur = S.players[me].finalRole;
    S.nightInfo = { icon: ROLES[cur].icon, text: 'あなたの今のカードは「' + ROLES[cur].name + '」です' };
    S.log.push('🦉 不眠症（' + S.players[me].name + '）は自分のカードを確認した');
    return nightActionHTML(me);
  }
  // 村人
  S.nightStep = 'outcome';
  S.nightInfo = { icon: '🌙', text: '静かな夜です。そのまま朝を待ちましょう。' };
  return nightActionHTML(me);
}

function doNightPick(me, target) {
  const role = S.players[me].initialRole;
  if (role === 'seer') {
    const t = S.players[target];
    S.nightStep = 'outcome';
    S.nightInfo = { icon: ROLES[t.finalRole].icon, text: esc(t.name) + ' さんのカードは「' + ROLES[t.finalRole].name + '」でした' };
    S.log.push('🔮 占い師（' + S.players[me].name + '）は ' + t.name + ' のカードを見た');
  } else if (role === 'robber') {
    const t = S.players[target];
    const mine = S.players[me].finalRole;
    S.players[me].finalRole = t.finalRole;
    t.finalRole = mine;
    S.nightStep = 'outcome';
    S.nightInfo = { icon: ROLES[S.players[me].finalRole].icon, text: esc(t.name) + ' さんと交換しました。<br>あなたの新しい役職は「' + ROLES[S.players[me].finalRole].name + '」です' };
    S.log.push('🌀 怪盗（' + S.players[me].name + '）は ' + t.name + ' とカードを交換した');
  }
  save(); render();
}

function doTroublemaker(me) {
  const picks = (S.nightInfo && S.nightInfo.picks) || [];
  if (picks.length !== 2) return;
  const a = picks[0], b = picks[1];
  const tmp = S.players[a].finalRole;
  S.players[a].finalRole = S.players[b].finalRole;
  S.players[b].finalRole = tmp;
  S.nightStep = 'outcome';
  S.nightInfo = { icon: '🔀', text: esc(S.players[a].name) + ' さんと ' + esc(S.players[b].name) + ' さんのカードを入れ替えました（中身は見ていません）' };
  S.log.push('🔀 トラブルメーカー（' + S.players[me].name + '）は ' + S.players[a].name + ' と ' + S.players[b].name + ' のカードを入れ替えた');
  save(); render();
}

function doDrunk(me, idx) {
  const tmp = S.players[me].finalRole;
  S.players[me].finalRole = S.center[idx];
  S.center[idx] = tmp;
  S.nightStep = 'outcome';
  S.nightInfo = { icon: '🍺', text: '中央のカードと交換しました。<br>新しい役職は朝のお楽しみです。' };
  S.log.push('🍺 酔っぱらい（' + S.players[me].name + '）は中央のカードと交換した');
  save(); render();
}

// ---------- 投票・結果 ----------
function computeResult() {
  const count = S.players.length;
  const received = new Array(count).fill(0);
  S.votes.forEach(v => { if (v >= 0) received[v]++; });
  const max = Math.max.apply(null, received);
  const executed = S.players.map((p, i) => i).filter(i => received[i] === max);
  const wolfInPlayers = S.players.some(p => p.finalRole === 'werewolf');
  const minionInPlayers = S.players.some(p => p.finalRole === 'minion');
  let villageWin;
  if (executed.some(i => S.players[i].finalRole === 'werewolf')) villageWin = true;
  else if (!wolfInPlayers && minionInPlayers) villageWin = executed.some(i => S.players[i].finalRole === 'minion');
  else if (!wolfInPlayers) villageWin = executed.every(i => S.players[i].finalRole === 'villager');
  else villageWin = false;
  return { received, executed, wolfInPlayers, villageWin };
}

// ---------- 描画 ----------
let timerId = null;
function stopTimer() { if (timerId) { clearInterval(timerId); timerId = null; } }

function render() {
  stopTimer();
  const sc = S.screen;
  if (sc === 'setup') return renderSetup();
  if (sc === 'nightIntro') {
    $screen.innerHTML = '<div class="card"><p class="big">🌙 夜が来ました</p>' +
      '<p>カードを配りました。<br>これから1人ずつ端末を受け取り、自分の役職を確認します。<br>画面は本人以外見ないでください。</p>' +
      '<button id="go">夜の行動をはじめる</button></div>';
    document.getElementById('go').onclick = () => { S.screen = 'nightHandoff'; save(); render(); };
    return;
  }
  if (sc === 'nightHandoff') {
    const me = currentNightPlayer();
    $screen.innerHTML = '<div class="card handoff"><p class="big">📱 ' + esc(S.players[me].name) + ' さんに渡してください</p>' +
      '<p class="small">本人のみが次のボタンを押してください</p>' +
      '<button id="go">自分のカードを見る</button></div>';
    document.getElementById('go').onclick = beginNightTurn;
    return;
  }
  if (sc === 'nightRole') return renderNightRole();
  if (sc === 'discuss') return renderDiscuss();
  if (sc === 'voteHandoff') {
    const me = S.votePos;
    $screen.innerHTML = '<div class="card handoff"><p class="big">🗳 ' + esc(S.players[me].name) + ' さんに渡してください</p>' +
      '<p class="small">投票は本人だけが見てください</p>' +
      '<button id="go">投票する</button></div>';
    document.getElementById('go').onclick = () => { S.screen = 'votePick'; save(); render(); };
    return;
  }
  if (sc === 'votePick') return renderVotePick();
  if (sc === 'result') return renderResult();
}

function renderSetup() {
  const st = S.settings;
  const specialsPicked = SPECIAL_ROLES.filter(r => st.roles[r]);
  const villagerCount = st.count + 2 - 2 - specialsPicked.length;
  const compText = '人狼×2' + (specialsPicked.length ? '・' + specialsPicked.map(r => ROLES[r].name).join('・') : '') +
    '・村人×' + villagerCount + '（全' + (st.count + 2) + '枚）';
  let nameInputs = '';
  for (let i = 0; i < st.count; i++) {
    nameInputs += '<label>プレイヤー' + (i + 1) + 'の名前<input type="text" id="name' + i + '" value="' + esc(st.names[i] || '') + '" placeholder="プレイヤー' + (i + 1) + '"></label>';
  }
  $screen.innerHTML =
    '<div class="card"><p>1台のスマホを回して遊ぶ、一夜完結の人狼ゲームです。<br>3〜6人で遊べます。</p>' +
    '<label>人数<select id="count">' +
    [3, 4, 5, 6].map(n => '<option value="' + n + '"' + (st.count === n ? ' selected' : '') + '>' + n + '人</option>').join('') +
    '</select></label>' + nameInputs +
    '<label>議論の時間<select id="minutes">' +
    [1, 3, 5].map(n => '<option value="' + n + '"' + (st.minutes === n ? ' selected' : '') + '>' + n + '分</option>').join('') +
    '</select></label>' +
    '<label>使う役職（人狼×2は固定）</label>' +
    SPECIAL_ROLES.map(r => '<label style="margin-top:2px"><input type="checkbox" class="rolechk" data-role="' + r + '"' + (st.roles[r] ? ' checked' : '') + ' style="width:auto"> ' + ROLES[r].icon + ' ' + ROLES[r].name + '</label>').join('') +
    '<p class="small">構成： ' + compText + '</p>' +
    (S.setupError ? '<p style="color:#ff9d9d">' + esc(S.setupError) + '</p>' : '') +
    '<button id="start">ゲームスタート</button></div>' +
    '<details><summary>遊び方・ルール</summary>' +
    '<p>役職は人数＋2枚（中央に2枚残ります）。人狼×2は固定で、特殊役職は設定で選べます。残りは村人です。</p>' +
    '<ul>' +
    '<li>夜：全員が1回ずつ端末を受け取り、自分の役職を確認して行動します（人狼は仲間の確認、狂人は人狼の確認、占い師はカードをのぞく、怪盗はだれかと交換、トラブルメーカーは他の2人のカードを入れ替え、酔っぱらいは中央のカードと交換、不眠症は自分の最終カードを確認）。</li>' +
    '<li>朝：タイマーの時間だけ話し合い、人狼だと思う人を全員で投票します。最多得票の人が処刑されます（同点は全員処刑）。</li>' +
    '<li>勝敗：処刑された人の中に人狼がいれば村人陣営の勝ち。狂人を処刑しても村人陣営の勝ちにはなりません。プレイヤーの中に人狼が1人もいないときは、狂人がいれば狂人の処刑で、いなければ村人の処刑で村人陣営の勝ちです。</li>' +
    '<li>勝敗は「最後に持っていたカード」の役職で決まります。怪盗に交換されたら役職も入れ替わります。</li>' +
    '</ul></details>';
  const readInputs = () => {
    st.count = parseInt(document.getElementById('count').value, 10);
    st.minutes = parseInt(document.getElementById('minutes').value, 10);
    for (let i = 0; i < 6; i++) {
      const el = document.getElementById('name' + i);
      if (el) st.names[i] = el.value;
    }
  };
  document.getElementById('count').onchange = () => { readInputs(); save(); render(); };
  document.getElementById('minutes').onchange = () => { readInputs(); save(); };
  $screen.querySelectorAll('.rolechk').forEach(chk => chk.onchange = () => {
    readInputs();
    st.roles[chk.getAttribute('data-role')] = chk.checked;
    save(); render();
  });
  for (let i = 0; i < st.count; i++) {
    document.getElementById('name' + i).oninput = e => { st.names[i] = e.target.value; save(); };
  }
  document.getElementById('start').onclick = () => { readInputs(); save(); startGame(); };
}

function renderNightRole() {
  const me = currentNightPlayer();
  const role = ROLES[S.players[me].initialRole];
  let html = '<p class="small">' + esc(S.players[me].name) + ' さんの役職</p>' +
    '<div class="roleicon">' + role.icon + '</div><div class="rolename">' + role.name + '</div>';
  html += nightActionHTML(me);
  $screen.innerHTML = html;
  // イベント配線
  const done = document.getElementById('doneBtn');
  if (done) done.onclick = endNightTurn;
  $screen.querySelectorAll('[data-center]').forEach(b => b.onclick = () => {
    const idx = parseInt(b.getAttribute('data-center'), 10);
    const r = S.center[idx];
    S.nightStep = 'outcome';
    S.nightInfo = { icon: ROLES[r].icon, text: '中央のカードは「' + ROLES[r].name + '」でした' };
    S.log.push('🐺 一匹狼（' + S.players[me].name + '）は中央のカードをのぞいた');
    save(); render();
  });
  const sp = document.getElementById('seerPlayer');
  if (sp) sp.onclick = () => { S.nightStep = 'pick'; save(); render(); };
  const sct = document.getElementById('seerCenter');
  if (sct) sct.onclick = () => {
    S.nightStep = 'outcome';
    S.nightInfo = { icon: '🃏', text: '中央のカードは「' + ROLES[S.center[0]].name + '」と「' + ROLES[S.center[1]].name + '」でした' };
    S.log.push('🔮 占い師（' + S.players[me].name + '）は中央のカード2枚を見た');
    save(); render();
  };
  const rs = document.getElementById('robberSkip');
  if (rs) rs.onclick = () => {
    S.nightStep = 'outcome';
    S.nightInfo = { icon: '🌀', text: '交換しませんでした。あなたの役職は「怪盗」のままです。' };
    S.log.push('🌀 怪盗（' + S.players[me].name + '）は交換しなかった');
    save(); render();
  };
  $screen.querySelectorAll('[data-tmpick]').forEach(b => b.onclick = () => {
    const i = parseInt(b.getAttribute('data-tmpick'), 10);
    const picks = S.nightInfo.picks;
    const at = picks.indexOf(i);
    if (at >= 0) picks.splice(at, 1);
    else if (picks.length < 2) picks.push(i);
    save(); render();
  });
  const tmc = document.getElementById('tmConfirm');
  if (tmc) tmc.onclick = () => doTroublemaker(me);
  const tms = document.getElementById('tmSkip');
  if (tms) tms.onclick = () => {
    S.nightStep = 'outcome';
    S.nightInfo = { icon: '🔀', text: '入れ替えませんでした。' };
    S.log.push('🔀 トラブルメーカー（' + S.players[me].name + '）は入れ替えなかった');
    save(); render();
  };
  $screen.querySelectorAll('[data-drunk]').forEach(b => b.onclick = () => doDrunk(me, parseInt(b.getAttribute('data-drunk'), 10)));
  $screen.querySelectorAll('[data-target]').forEach(b => b.onclick = () => doNightPick(me, parseInt(b.getAttribute('data-target'), 10)));
}

function renderDiscuss() {
  const left = S.timerOn ? Math.max(0, Math.round((S.discussEndsAt - Date.now()) / 1000)) : S.discussLeft;
  const mm = Math.floor(left / 60), ss = ('0' + (left % 60)).slice(-2);
  $screen.innerHTML = '<div class="card"><p class="big">☀️ 朝になりました</p>' +
    '<p>話し合って、人狼だと思う人を決めましょう。</p>' +
    '<div class="timer">' + mm + ':' + ss + '</div>' +
    (S.timerOn
      ? '<button class="sub" id="pause">一時停止</button>'
      : '<button class="sub" id="startT">タイマースタート</button>') +
    '<button class="sub" id="resetT">リセット</button>' +
    '<p class="small">時間になったら（ならなくても）投票へ進めます</p>' +
    '<button id="toVote">投票へ進む</button></div>';
  const startBtn = document.getElementById('startT');
  if (startBtn) startBtn.onclick = () => {
    S.discussEndsAt = Date.now() + S.discussLeft * 1000;
    S.timerOn = true; save(); render();
  };
  const pauseBtn = document.getElementById('pause');
  if (pauseBtn) pauseBtn.onclick = () => {
    S.discussLeft = Math.max(0, Math.round((S.discussEndsAt - Date.now()) / 1000));
    S.timerOn = false; save(); render();
  };
  document.getElementById('resetT').onclick = () => {
    S.discussLeft = S.settings.minutes * 60; S.timerOn = false; save(); render();
  };
  document.getElementById('toVote').onclick = () => {
    S.timerOn = false; S.votePos = 0; S.screen = 'voteHandoff'; save(); render();
  };
  if (S.timerOn) {
    timerId = setInterval(() => {
      const l = Math.max(0, Math.round((S.discussEndsAt - Date.now()) / 1000));
      const el = $screen.querySelector('.timer');
      if (el) el.textContent = Math.floor(l / 60) + ':' + ('0' + (l % 60)).slice(-2);
      if (l <= 0) { stopTimer(); S.timerOn = false; S.discussLeft = 0; save(); }
    }, 250);
  }
}

function renderVotePick() {
  const me = S.votePos;
  $screen.innerHTML = '<p class="big">🗳 ' + esc(S.players[me].name) + ' さんの投票</p>' +
    '<p>人狼だと思う人を1人選んでください。</p>' +
    S.players.map((p, i) => i === me ? '' :
      '<button class="pick" data-vote="' + i + '">' + esc(p.name) + ' さん</button>').join('');
  $screen.querySelectorAll('[data-vote]').forEach(b => b.onclick = () => {
    S.votes[me] = parseInt(b.getAttribute('data-vote'), 10);
    S.votePos++;
    S.screen = S.votePos >= S.players.length ? 'result' : 'voteHandoff';
    save(); render();
  });
}

function renderResult() {
  const r = computeResult();
  const rows = S.players.map((p, i) => {
    const isEx = r.executed.includes(i);
    const team = ROLES[p.finalRole].team;
    const won = (team === 'village') === r.villageWin;
    const changed = p.initialRole !== p.finalRole;
    return '<tr><td>' + esc(p.name) + (isEx ? ' 💀' : '') + '</td>' +
      '<td>' + ROLES[p.initialRole].icon + ROLES[p.initialRole].name +
      (changed ? ' → ' + ROLES[p.finalRole].icon + ROLES[p.finalRole].name : '') + '</td>' +
      '<td>' + r.received[i] + '票</td>' +
      '<td class="' + (won ? 'win' : '') + '">' + (won ? '勝ち' : '負け') + '</td></tr>';
  }).join('');
  $screen.innerHTML =
    '<div class="card"><p class="big">' + (r.villageWin ? '🎉 村人陣営の勝ち！' : '🐺 人狼陣営の勝ち！') + '</p>' +
    '<p>処刑されたのは ' + r.executed.map(i => esc(S.players[i].name)).join('、') + ' さんでした。' +
    (r.wolfInPlayers ? '' : '<br>※ プレイヤーの中に人狼はいませんでした。') + '</p></div>' +
    '<div class="card"><table><tr><th>名前</th><th>役職</th><th>得票</th><th>結果</th></tr>' + rows + '</table>' +
    '<p class="small">中央のカード： ' + S.center.map(c => ROLES[c].icon + ROLES[c].name).join(' / ') + '</p></div>' +
    (S.log.length ? '<div class="card"><p class="big">🌙 夜の出来事</p><p style="text-align:left">' +
      S.log.map(esc).join('<br>') + '</p></div>' : '') +
    '<button id="again">同じメンバーでもう一度</button>' +
    '<button class="sub" id="back">設定に戻る</button>';
  document.getElementById('again').onclick = () => startGame();
  document.getElementById('back').onclick = () => {
    const st = S.settings;
    S = freshState(); S.settings = st;
    save(); render();
  };
}

// ---------- 起動 ----------
if (!load()) { S = freshState(); }
render();
