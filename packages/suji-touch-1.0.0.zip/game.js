(function () {
  var store = { get: function (k) { try { return store.get(k); } catch (e) { return null; } }, set: function (k, v) { try { store.set(k, v); } catch (e) {} } };
  var MAX = 20;
  var grid = document.getElementById('grid');
  var nextEl = document.getElementById('next');
  var timeEl = document.getElementById('time');
  var bestEl = document.getElementById('best');
  var msgEl = document.getElementById('message');
  var startBtn = document.getElementById('startBtn');
  var next = 1, startAt = 0, timer = null, playing = false;

  var best = parseFloat(store.get('suji_best') || '0');
  if (best > 0) bestEl.textContent = best.toFixed(1) + '秒';

  function build() {
    grid.innerHTML = '';
    var nums = [];
    for (var i = 1; i <= MAX; i++) nums.push(i);
    for (var j = nums.length - 1; j > 0; j--) {
      var k = Math.floor(Math.random() * (j + 1));
      var t = nums[j]; nums[j] = nums[k]; nums[k] = t;
    }
    nums.forEach(function (n) {
      var d = document.createElement('div');
      d.className = 'num';
      d.textContent = n;
      d.addEventListener('pointerdown', function () {
        if (!playing || d.classList.contains('done')) return;
        if (n === next) {
          d.classList.add('done');
          next += 1;
          nextEl.textContent = next > MAX ? '―' : next;
          if (next > MAX) finish();
        }
      });
      grid.appendChild(d);
    });
  }
  function finish() {
    playing = false;
    clearInterval(timer);
    var t = (Date.now() - startAt) / 1000;
    timeEl.textContent = t.toFixed(1);
    var isBest = false;
    if (best === 0 || t < best) {
      best = t;
      store.set('suji_best', String(t));
      bestEl.textContent = t.toFixed(1) + '秒';
      isBest = true;
    }
    msgEl.innerHTML = 'クリア！ タイムは <b>' + t.toFixed(1) + '秒</b> でした。' + (isBest ? '<br>ベストタイム更新！' : '<br>ベストタイム: <b>' + best.toFixed(1) + '秒</b>');
    startBtn.textContent = 'もう一度';
    startBtn.style.display = '';
  }
  startBtn.addEventListener('click', function () {
    next = 1; playing = true;
    nextEl.textContent = '1'; timeEl.textContent = '0.0';
    msgEl.textContent = 'がんばって！';
    startBtn.style.display = 'none';
    build();
    startAt = Date.now();
    timer = setInterval(function () {
      timeEl.textContent = ((Date.now() - startAt) / 1000).toFixed(1);
    }, 100);
  });
  build();
})();
